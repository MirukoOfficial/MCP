import {
  DEFAULT_DECOMPILER_RUNTIME_SETTINGS,
  DEFAULT_PROVIDER_TIMEOUTS_MS,
  FISSION_DEFAULT_OPTIONS,
  FISSION_SAFE_FLAGS,
  isCustomDecompilerProviderId,
  isDecompilerProviderId,
  type DecompilerProviderId,
  type DecompilerProviderSettings,
  type DecompilerRuntimeSettings,
  type DecompilerSettings,
  type FissionBytecodeMode,
  type FissionSafeFlag,
} from "./settings.js";
import {
  getDecompilerProviderStatus,
  recordDecompilerProviderFailure,
  recordDecompilerProviderSuccess,
  shouldSkipDecompilerProvider,
} from "./health.js";
import { compileCustomDecompilerWorkflow } from "./custom-workflow.js";
import { WebSocket } from "ws";

export interface DecompileInput {
  bytecodeBase64: string;
  builtinAvailable?: boolean;
  builtinSource?: string;
  builtinLatencyMs?: number;
  clientId?: string;
  requestedProvider?: string;
  disabledProviders?: unknown[];
}

export interface DecompileResult {
  ok: boolean;
  source?: string;
  providerId?: DecompilerProviderId;
  attempts: string[];
  attemptedProviders: DecompilerProviderId[];
  error?: string;
  needsBuiltin?: boolean;
}

interface ProviderRunResult {
  ok: boolean;
  result?: string;
  error?: string;
  statusCode?: number;
  timedOut?: boolean;
  latencyMs: number;
}

const ENDPOINT_BRIDGE_HOST_TOKEN = "{{BridgeHost}}";
const MAX_ERROR_BODY_CHARS = 600;
const FISSION_MAX_REQUEST_BYTES = 32 * 1024 * 1024;
const LUA_EXPERT_MIN_INTERVAL_MS = 120;
const LOAD_IDLE_RESET_MS = 5000;
let luaExpertLastCallAt = 0;
let luaExpertQueue: Promise<void> = Promise.resolve();

interface ProviderLoadState {
  active: number;
  recentAssignments: number;
  lastAssignedAtMs: number;
}

const providerLoadById = new Map<DecompilerProviderId, ProviderLoadState>();

function providerDisplayName(id: DecompilerProviderId, provider: DecompilerProviderSettings): string {
  if (id === "luaexpert") return "lua.expert";
  if (id === "shiny") return provider.options.mode === "hosted" ? "Shiny hosted" : "Shiny";
  if (id === "luacid") return "Luacid";
  if (id === "oracle") return "Oracle";
  if (id === "konstant") return "Konstant";
  if (id === "fission") return "Fission";
  if (isCustomDecompilerProviderId(id)) {
    const name = provider.options.name;
    return typeof name === "string" && name.trim()
      ? name.trim().replace(/\s+/g, " ").slice(0, 80)
      : "custom provider";
  }
  return "built-in";
}

function providerLoad(id: DecompilerProviderId): ProviderLoadState {
  let load = providerLoadById.get(id);
  const now = Date.now();
  if (!load) {
    load = { active: 0, recentAssignments: 0, lastAssignedAtMs: 0 };
    providerLoadById.set(id, load);
  }
  if (load.active === 0 && now - load.lastAssignedAtMs > LOAD_IDLE_RESET_MS) {
    load.recentAssignments = 0;
  }
  return load;
}

function startProviderAttempt(id: DecompilerProviderId): () => void {
  const load = providerLoad(id);
  load.active += 1;
  load.recentAssignments += 1;
  load.lastAssignedAtMs = Date.now();

  return () => {
    const current = providerLoad(id);
    current.active = Math.max(0, current.active - 1);
  };
}

function providerLoadScore(id: DecompilerProviderId): number {
  const load = providerLoad(id);
  return load.active * 1000 + load.recentAssignments;
}

function cleanDisabledProviders(value: unknown[] | undefined): Set<DecompilerProviderId> {
  const disabled = new Set<DecompilerProviderId>();
  if (!Array.isArray(value)) return disabled;
  for (const item of value) {
    if (isDecompilerProviderId(item)) disabled.add(item);
  }
  return disabled;
}

function orderProvidersForRequest(
  candidates: DecompilerProviderId[],
  runtime: DecompilerRuntimeSettings,
  requestedProvider: DecompilerProviderId | null,
  clientId = "server"
): DecompilerProviderId[] {
  if (requestedProvider && candidates.includes(requestedProvider)) {
    return [requestedProvider, ...candidates.filter((id) => id !== requestedProvider)];
  }

  const firstCandidate = candidates[0];
  if (
    runtime.loadBalanceSlowProviders === false ||
    !firstCandidate ||
    getDecompilerProviderStatus(firstCandidate, clientId) !== "slow"
  ) {
    return candidates;
  }

  const priorityIndex = new Map(candidates.map((id, index) => [id, index]));
  return [...candidates].sort((left, right) => {
    const leftScore = providerLoadScore(left);
    const rightScore = providerLoadScore(right);
    if (leftScore !== rightScore) return leftScore - rightScore;
    return (priorityIndex.get(left) ?? 0) - (priorityIndex.get(right) ?? 0);
  });
}

function resolveProviderEndpoint(endpoint: string): string {
  return endpoint.replaceAll(ENDPOINT_BRIDGE_HOST_TOKEN, "localhost");
}

function truncateErrorBody(body: string): string {
  return body.length > MAX_ERROR_BODY_CHARS
    ? `${body.slice(0, MAX_ERROR_BODY_CHARS)}...(truncated)`
    : body;
}

function isUnusableDecompiledSource(source: string): boolean {
  const trimmed = source.trim();
  if (!trimmed) return true;
  const lowered = trimmed.toLowerCase();
  return (
    lowered.includes("failed to decompile") ||
    lowered.includes("decompiler server not active") ||
    lowered.includes("decompiler is not active")
  );
}

function bufferToArrayBuffer(buffer: Buffer): ArrayBuffer {
  const bytes = new Uint8Array(buffer.byteLength);
  bytes.set(buffer);
  return bytes.buffer;
}

function delay(ms: number): Promise<void> {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

async function withLuaExpertRateLimit<T>(run: () => Promise<T>): Promise<T> {
  const previous = luaExpertQueue;
  let release: () => void = () => undefined;
  luaExpertQueue = new Promise<void>((resolve) => {
    release = resolve;
  });

  await previous;
  try {
    const waitMs = Math.max(0, LUA_EXPERT_MIN_INTERVAL_MS - (Date.now() - luaExpertLastCallAt));
    if (waitMs > 0) await delay(waitMs);
    return await run();
  } finally {
    luaExpertLastCallAt = Date.now();
    release();
  }
}

function withQuery(endpoint: string, params: Record<string, string | number | boolean | null | undefined>): string {
  try {
    const url = new URL(endpoint);
    for (const [key, value] of Object.entries(params)) {
      if (value !== undefined && value !== null && value !== "") {
        url.searchParams.set(key, String(value));
      }
    }
    return url.toString();
  } catch {
    const parts = Object.entries(params)
      .filter(([, value]) => value !== undefined && value !== null && value !== "")
      .map(([key, value]) => `${encodeURIComponent(key)}=${encodeURIComponent(String(value))}`);
    if (parts.length === 0) return endpoint;
    return `${endpoint}${endpoint.includes("?") ? "&" : "?"}${parts.join("&")}`;
  }
}

async function fetchText(
  url: string,
  init: Omit<RequestInit, "signal">,
  timeoutMs: number
): Promise<ProviderRunResult> {
  const startedAt = Date.now();
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);

  try {
    const response = await fetch(url, { ...init, signal: controller.signal });
    const body = await response.text();
    const latencyMs = Date.now() - startedAt;
    if (!response.ok) {
      return {
        ok: false,
        error: `HTTP ${response.status}: ${truncateErrorBody(body)}`,
        statusCode: response.status,
        latencyMs,
      };
    }

    return {
      ok: true,
      result: body.replaceAll(String.fromCharCode(0x00CD), " "),
      statusCode: response.status,
      latencyMs,
    };
  } catch (error) {
    const latencyMs = Date.now() - startedAt;
    const timedOut = error instanceof Error && error.name === "AbortError";
    return {
      ok: false,
      error: timedOut
        ? `Timed out after ${Math.round(timeoutMs / 100) / 10}s.`
        : error instanceof Error
          ? error.message
          : String(error),
      timedOut,
      latencyMs,
    };
  } finally {
    clearTimeout(timer);
  }
}

async function runLuaExpert(
  provider: DecompilerProviderSettings,
  bytecodeBase64: string,
  timeoutMs: number
): Promise<ProviderRunResult> {
  return withLuaExpertRateLimit(() =>
    fetchText(
      resolveProviderEndpoint(provider.endpoint),
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ script: bytecodeBase64 }),
      },
      timeoutMs
    )
  );
}

async function runPlainBase64(
  provider: DecompilerProviderSettings,
  bytecodeBase64: string,
  timeoutMs: number
): Promise<ProviderRunResult> {
  return fetchText(
    resolveProviderEndpoint(provider.endpoint),
    {
      method: "POST",
      headers: { "Content-Type": "text/plain" },
      body: bytecodeBase64,
    },
    timeoutMs
  );
}

function fissionMode(provider: DecompilerProviderSettings): FissionBytecodeMode {
  return provider.options.mode === "vanilla" ? "vanilla" : FISSION_DEFAULT_OPTIONS.mode;
}

function fissionFlag(provider: DecompilerProviderSettings, flag: FissionSafeFlag): boolean {
  const value = provider.options[flag];
  return typeof value === "boolean" ? value : FISSION_DEFAULT_OPTIONS[flag];
}

function buildFissionRequestBody(
  bytecodeBase64: string,
  provider: DecompilerProviderSettings,
  timeoutMs: number
): { body: string } | { error: string } {
  if (!bytecodeBase64) {
    return { error: "Fission request is missing bytecode." };
  }

  const flags: Partial<Record<FissionSafeFlag, true>> = {};
  for (const flag of FISSION_SAFE_FLAGS) {
    if (fissionFlag(provider, flag)) flags[flag] = true;
  }

  const payload: Record<string, unknown> = {
    mode: fissionMode(provider),
    bytecode: bytecodeBase64,
  };
  if (Object.keys(flags).length > 0) payload.flags = flags;

  const timeoutSeconds = Math.floor(timeoutMs / 1000);
  if (timeoutSeconds > 0) payload.timeout = timeoutSeconds;

  const body = JSON.stringify(payload);
  if (Buffer.byteLength(body, "utf8") > FISSION_MAX_REQUEST_BYTES) {
    return { error: "Fission request exceeds the 32 MiB body limit." };
  }
  return { body };
}

function parseFissionResponse(
  status: number,
  body: string,
  latencyMs: number
): ProviderRunResult {
  let parsed: unknown;
  try {
    parsed = JSON.parse(body);
  } catch {
    if (status < 200 || status >= 300) {
      return {
        ok: false,
        error: `HTTP ${status}: ${truncateErrorBody(body)}`,
        statusCode: status,
        latencyMs,
      };
    }
    return {
      ok: false,
      error: "Fission returned invalid JSON.",
      statusCode: status,
      latencyMs,
    };
  }

  if (!parsed || typeof parsed !== "object" || Array.isArray(parsed)) {
    return {
      ok: false,
      error: "Fission returned an invalid response object.",
      statusCode: status,
      latencyMs,
    };
  }

  const payload = parsed as Record<string, unknown>;
  if (payload.ok === false) {
    const message =
      typeof payload.error === "string" && payload.error.trim()
        ? payload.error.trim()
        : "Fission decompile failed.";
    return {
      ok: false,
      error: `HTTP ${status}: ${truncateErrorBody(message)}`,
      statusCode: status,
      latencyMs,
    };
  }

  if (status < 200 || status >= 300) {
    return {
      ok: false,
      error: `HTTP ${status}: ${truncateErrorBody(body)}`,
      statusCode: status,
      latencyMs,
    };
  }

  if (payload.ok !== true) {
    return {
      ok: false,
      error: "Fission response is missing a boolean ok field.",
      statusCode: status,
      latencyMs,
    };
  }

  const result = payload.result;
  if (!result || typeof result !== "object" || Array.isArray(result)) {
    return {
      ok: false,
      error: "Fission success response is missing result.",
      statusCode: status,
      latencyMs,
    };
  }

  const source = (result as Record<string, unknown>).decompilationOutput;
  if (typeof source !== "string") {
    return {
      ok: false,
      error: "Fission success response is missing decompilationOutput.",
      statusCode: status,
      latencyMs,
    };
  }

  return {
    ok: true,
    result: source.replaceAll(String.fromCharCode(0x00CD), " "),
    statusCode: status,
    latencyMs,
  };
}

async function runFission(
  provider: DecompilerProviderSettings,
  bytecodeBase64: string,
  timeoutMs: number
): Promise<ProviderRunResult> {
  const request = buildFissionRequestBody(bytecodeBase64, provider, timeoutMs);
  if ("error" in request) {
    return { ok: false, error: request.error, latencyMs: 0 };
  }

  const startedAt = Date.now();
  const controller = new AbortController();
  const timer = setTimeout(() => controller.abort(), timeoutMs);

  try {
    const response = await fetch(resolveProviderEndpoint(provider.endpoint), {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: request.body,
      signal: controller.signal,
    });
    const body = await response.text();
    return parseFissionResponse(response.status, body, Date.now() - startedAt);
  } catch (error) {
    const latencyMs = Date.now() - startedAt;
    const timedOut = error instanceof Error && error.name === "AbortError";
    return {
      ok: false,
      error: timedOut
        ? `Timed out after ${Math.round(timeoutMs / 100) / 10}s.`
        : error instanceof Error
          ? error.message
          : String(error),
      timedOut,
      latencyMs,
    };
  } finally {
    clearTimeout(timer);
  }
}

async function runPlainBytecode(
  provider: DecompilerProviderSettings,
  bytecode: Buffer,
  timeoutMs: number
): Promise<ProviderRunResult> {
  return fetchText(
    resolveProviderEndpoint(provider.endpoint),
    {
      method: "POST",
      headers: { "Content-Type": "text/plain" },
      body: bufferToArrayBuffer(bytecode),
    },
    timeoutMs
  );
}

async function runOracle(
  provider: DecompilerProviderSettings,
  bytecodeBase64: string,
  timeoutMs: number
): Promise<ProviderRunResult> {
  if (!provider.apiKey) {
    return {
      ok: false,
      error: "Oracle API key is not configured.",
      latencyMs: 0,
    };
  }

  const url = withQuery(resolveProviderEndpoint(provider.endpoint), {
    key: provider.apiKey,
    version: provider.version,
  });

  return fetchText(
    url,
    {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        script: bytecodeBase64,
        decompilerOptions: provider.options,
      }),
    },
    timeoutMs
  );
}

function luacidOptions(
  provider: DecompilerProviderSettings
): Record<string, string | number | boolean> {
  return Object.fromEntries(Object.entries(provider.options).filter(
    ([key, value]) => !["transport", "transportExplicit"].includes(key) && ["string", "number", "boolean"].includes(typeof value)
  )) as Record<string, string | number | boolean>;
}

async function runLuacid(
  provider: DecompilerProviderSettings,
  bytecode: Buffer,
  bytecodeBase64: string,
  timeoutMs: number
): Promise<ProviderRunResult> {
  const options = luacidOptions(provider);
  const explicitHttp = provider.options.transport === "http" && provider.options.transportExplicit === true;
  const useWebSocket = provider.options.transport === "websocket" ||
    (!explicitHttp && Boolean(provider.apiKey));
  if (!useWebSocket) {
    const headers: Record<string, string> = { "Content-Type": "application/octet-stream" };
    if (provider.apiKey) headers.Authorization = `Bearer ${provider.apiKey}`;
    return fetchText(
      withQuery(resolveProviderEndpoint(provider.endpoint), options),
      { method: "POST", headers, body: bufferToArrayBuffer(bytecode) },
      timeoutMs
    );
  }

  if (!provider.apiKey) {
    return { ok: false, error: "Luacid WebSocket requires a paid API key.", latencyMs: 0 };
  }

  const startedAt = Date.now();
  return new Promise((resolve) => {
    const websocketEndpoint = resolveProviderEndpoint(provider.endpoint)
      .replace(/^http/, "ws")
      .replace(/\/decompile\/?$/, "/decompile_ws");
    const url = withQuery(websocketEndpoint, options);
    const socket = new WebSocket(url, { headers: { Authorization: `Bearer ${provider.apiKey}` } });
    let settled = false;
    const finish = (result: ProviderRunResult) => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      socket.close();
      resolve(result);
    };
    const timer = setTimeout(() => {
      if (settled) return;
      settled = true;
      socket.terminate();
      resolve({
        ok: false,
        error: `Timed out after ${Math.round(timeoutMs / 100) / 10}s.`,
        timedOut: true,
        latencyMs: Date.now() - startedAt,
      });
    }, timeoutMs);

    socket.once("open", () => socket.send(JSON.stringify({
      id: "decompile",
      encoded_bytecode: bytecodeBase64,
      ...options,
    })));
    socket.once("message", (data) => {
      try {
        const response = JSON.parse(data.toString()) as {
          decompilation?: unknown;
          error?: { message?: unknown };
        };
        if (typeof response.decompilation === "string") {
          finish({ ok: true, result: response.decompilation, latencyMs: Date.now() - startedAt });
        } else {
          finish({
            ok: false,
            error: typeof response.error?.message === "string" ? response.error.message : "Invalid Luacid WebSocket response.",
            latencyMs: Date.now() - startedAt,
          });
        }
      } catch {
        finish({ ok: false, error: "Invalid Luacid WebSocket response.", latencyMs: Date.now() - startedAt });
      }
    });
    socket.once("error", (error) => finish({ ok: false, error: error.message, latencyMs: Date.now() - startedAt }));
  });
}

function customOptionString(
  provider: DecompilerProviderSettings,
  key: string,
  fallback: string
): string {
  const value = provider.options[key];
  return typeof value === "string" && value.trim() ? value.trim() : fallback;
}

function customOptionTemplate(
  provider: DecompilerProviderSettings,
  key: string,
  fallback: string
): string {
  const value = provider.options[key];
  return typeof value === "string" ? value : fallback;
}

function customHeaders(provider: DecompilerProviderSettings): Record<string, string> {
  const configured = provider.options.headers;
  const headers: Record<string, string> = {};
  if (configured && typeof configured === "object" && !Array.isArray(configured)) {
    for (const [name, value] of Object.entries(configured)) {
      if (typeof value === "string" && name.trim()) headers[name.trim()] = value;
    }
  }

  if (provider.apiKey) {
    const configuredHeader = provider.options.apiKeyHeader;
    const header = typeof configuredHeader === "string"
      ? configuredHeader.trim()
      : "Authorization";
    if (!header) return headers;
    const configuredPrefix = provider.options.apiKeyPrefix;
    const prefix = typeof configuredPrefix === "string" ? configuredPrefix.trim() : "Bearer";
    const existingHeader = Object.keys(headers).find(
      (name) => name.toLowerCase() === header.toLowerCase()
    );
    if (existingHeader) delete headers[existingHeader];
    headers[header] = prefix ? `${prefix} ${provider.apiKey}` : provider.apiKey;
  }
  return headers;
}

type CustomTemplateValue = string | Buffer;

function customTemplateVariables(
  provider: DecompilerProviderSettings,
  bytecode: Buffer,
  bytecodeBase64: string
): Record<string, CustomTemplateValue> {
  const values: Record<string, CustomTemplateValue> = { api_key: provider.apiKey };
  const configured = provider.options.requestVariables;
  if (!Array.isArray(configured)) return values;
  for (const item of configured) {
    if (!item || typeof item !== "object" || Array.isArray(item)) continue;
    const name = (item as Record<string, unknown>).name;
    const value = (item as Record<string, unknown>).value;
    if (typeof name !== "string") continue;
    if (value === "bytecode") values[name] = bytecode;
    else if (value === "base64") values[name] = bytecodeBase64;
  }
  return values;
}

function renderCustomTemplate(
  template: string,
  values: Record<string, CustomTemplateValue>
): string {
  return template.replace(/\{\{\s*([A-Za-z_][A-Za-z0-9_]*)\s*\}\}/g, (_match, name: string) => {
    const value = values[name];
    const text = Buffer.isBuffer(value) ? value.toString("base64") : String(value ?? "");
    return JSON.stringify(text).slice(1, -1);
  });
}

function renderCustomHeadersTemplate(
  template: string,
  values: Record<string, CustomTemplateValue>
): Record<string, string> {
  const parsed: unknown = JSON.parse(renderCustomTemplate(template, values));
  if (!parsed || typeof parsed !== "object" || Array.isArray(parsed)) {
    throw new Error("Rendered request headers must be a JSON object.");
  }
  const headers: Record<string, string> = {};
  for (const [name, value] of Object.entries(parsed)) {
    if (typeof value !== "string") throw new Error("Rendered request header values must be strings.");
    if (name.trim()) headers[name.trim()] = value;
  }
  return headers;
}

function renderCustomBodyTemplate(
  template: string,
  values: Record<string, CustomTemplateValue>
): { body: BodyInit; binary: boolean } {
  const exact = /^\s*\{\{\s*([A-Za-z_][A-Za-z0-9_]*)\s*\}\}\s*$/.exec(template);
  const exactValue = exact ? values[exact[1]] : undefined;
  if (Buffer.isBuffer(exactValue)) {
    return { body: bufferToArrayBuffer(exactValue), binary: true };
  }
  return { body: renderCustomTemplate(template, values), binary: false };
}

function setDefaultHeader(
  headers: Record<string, string>,
  name: string,
  value: string
): void {
  const exists = Object.keys(headers).some(
    (header) => header.toLowerCase() === name.toLowerCase()
  );
  if (!exists) headers[name] = value;
}

function valueAtJsonPath(value: unknown, path: string): unknown {
  if (!path) return value;
  let current = value;
  for (const segment of path.split(".").filter(Boolean)) {
    if (!current || typeof current !== "object") return undefined;
    current = (current as Record<string, unknown>)[segment];
  }
  return current;
}

async function runCustom(
  provider: DecompilerProviderSettings,
  bytecode: Buffer,
  bytecodeBase64: string,
  timeoutMs: number
): Promise<ProviderRunResult> {
  let effectiveProvider = provider;
  try {
    const workflow = compileCustomDecompilerWorkflow(provider.options.workflow);
    if (workflow) {
      effectiveProvider = {
        ...provider,
        endpoint: workflow.endpoint,
        options: { ...provider.options, ...workflow },
      };
    }
  } catch (error) {
    return {
      ok: false,
      error: `Invalid custom provider workflow: ${error instanceof Error ? error.message : String(error)}`,
      latencyMs: 0,
    };
  }

  const requestFormat = customOptionString(effectiveProvider, "requestFormat", "json-script");
  const headers = customHeaders(effectiveProvider);
  let body: BodyInit;

  if (requestFormat === "template") {
    const values = customTemplateVariables(effectiveProvider, bytecode, bytecodeBase64);
    const headersTemplate = customOptionTemplate(effectiveProvider, "requestHeadersTemplate", "{}");
    const bodyTemplate = customOptionTemplate(effectiveProvider, "requestBodyTemplate", "");
    try {
      Object.assign(headers, renderCustomHeadersTemplate(headersTemplate, values));
      const rendered = renderCustomBodyTemplate(bodyTemplate, values);
      body = rendered.body;
      if (rendered.binary) setDefaultHeader(headers, "Content-Type", "application/octet-stream");
      else {
        try {
          JSON.parse(String(body));
          setDefaultHeader(headers, "Content-Type", "application/json");
        } catch {
          setDefaultHeader(headers, "Content-Type", "text/plain");
        }
      }
    } catch (error) {
      return {
        ok: false,
        error: `Could not render custom request template: ${error instanceof Error ? error.message : String(error)}`,
        latencyMs: 0,
      };
    }
  } else if (requestFormat === "plain-base64") {
    setDefaultHeader(headers, "Content-Type", "text/plain");
    body = bytecodeBase64;
  } else if (requestFormat === "plain-bytecode") {
    setDefaultHeader(headers, "Content-Type", "application/octet-stream");
    body = bufferToArrayBuffer(bytecode);
  } else if (requestFormat === "json-script") {
    setDefaultHeader(headers, "Content-Type", "application/json");
    const requestField = customOptionString(effectiveProvider, "requestField", "script");
    body = JSON.stringify({ [requestField]: bytecodeBase64 });
  } else {
    return {
      ok: false,
      error: `Unsupported custom request format: ${requestFormat}`,
      latencyMs: 0,
    };
  }

  const result = await fetchText(
    resolveProviderEndpoint(effectiveProvider.endpoint),
    { method: "POST", headers, body },
    timeoutMs
  );
  if (!result.ok || typeof result.result !== "string") return result;

  if (customOptionString(effectiveProvider, "responseFormat", "text") !== "json") {
    return result;
  }

  try {
    const parsed: unknown = JSON.parse(result.result);
    const responseField = customOptionString(effectiveProvider, "responseField", "source");
    const source = valueAtJsonPath(parsed, responseField);
    if (typeof source !== "string") {
      return {
        ...result,
        ok: false,
        result: undefined,
        error: `Custom provider JSON response did not contain a string at "${responseField}".`,
      };
    }
    return { ...result, result: source };
  } catch {
    return {
      ...result,
      ok: false,
      result: undefined,
      error: "Custom provider returned invalid JSON.",
    };
  }
}

async function runProvider(options: {
  id: DecompilerProviderId;
  provider: DecompilerProviderSettings;
  bytecode: Buffer;
  bytecodeBase64: string;
  builtinSource?: string;
  builtinLatencyMs?: number;
  timeoutMs: number;
}): Promise<ProviderRunResult> {
  const startedAt = Date.now();

  if (options.id === "builtin") {
    if (!options.builtinSource) {
      return {
        ok: false,
        error: "Executor built-in decompile is unavailable or returned no source.",
        latencyMs: Date.now() - startedAt,
      };
    }
    return {
      ok: true,
      result: options.builtinSource,
      latencyMs: options.builtinLatencyMs ?? Date.now() - startedAt,
    };
  }

  if (options.id === "luaexpert") {
    return runLuaExpert(options.provider, options.bytecodeBase64, options.timeoutMs);
  }
  if (options.id === "shiny") {
    return runPlainBase64(options.provider, options.bytecodeBase64, options.timeoutMs);
  }
  if (options.id === "fission") {
    return runFission(options.provider, options.bytecodeBase64, options.timeoutMs);
  }
  if (options.id === "luacid") {
    return runLuacid(options.provider, options.bytecode, options.bytecodeBase64, options.timeoutMs);
  }
  if (options.id === "konstant") {
    return runPlainBytecode(options.provider, options.bytecode, options.timeoutMs);
  }
  if (options.id === "oracle") {
    return runOracle(options.provider, options.bytecodeBase64, options.timeoutMs);
  }
  if (isCustomDecompilerProviderId(options.id)) {
    return runCustom(
      options.provider,
      options.bytecode,
      options.bytecodeBase64,
      options.timeoutMs
    );
  }

  return {
    ok: false,
    error: `Unsupported decompiler provider: ${options.id}`,
    latencyMs: Date.now() - startedAt,
  };
}

function runtimeOrDefault(runtime: DecompilerSettings["runtime"]): DecompilerRuntimeSettings {
  return runtime ?? DEFAULT_DECOMPILER_RUNTIME_SETTINGS;
}

export interface ResolvedDecompilerProviders {
  orderedProviders: DecompilerProviderId[];
  skippedAttempts: string[];
}

export function resolveDecompilerProviders(
  settings: DecompilerSettings,
  options: Pick<DecompileInput, "requestedProvider" | "disabledProviders" | "clientId"> = {}
): ResolvedDecompilerProviders {
  const runtime = runtimeOrDefault(settings.runtime);
  const disabledProviders = cleanDisabledProviders(options.disabledProviders);
  const requestedProvider = isDecompilerProviderId(options.requestedProvider)
    ? options.requestedProvider
    : null;
  const candidates: DecompilerProviderId[] = [];
  const skippedAttempts: string[] = [];

  for (const id of settings.providerOrder) {
    const provider = settings.providers[id];
    if (!provider?.enabled || disabledProviders.has(id)) continue;

    const skip = shouldSkipDecompilerProvider(id, runtime, options.clientId);
    // A failed-script resync explicitly requests the provider that handled its
    // first attempt. Give that provider one real retry even while adaptive
    // health policy has it in cooldown; subsequent providers still follow the
    // normal filtered fallback plan.
    if (skip.skip && id !== requestedProvider) {
      skippedAttempts.push(
        `[${id}] skipped: ${skip.reason ?? "provider is temporarily unavailable"}`
      );
      continue;
    }

    candidates.push(id);
  }

  return {
    orderedProviders: orderProvidersForRequest(candidates, runtime, requestedProvider, options.clientId),
    skippedAttempts,
  };
}

export async function decompileBytecode(
  settings: DecompilerSettings,
  input: DecompileInput
): Promise<DecompileResult> {
  const runtime = runtimeOrDefault(settings.runtime);
  const bytecode = Buffer.from(input.bytecodeBase64, "base64");
  const resolved = resolveDecompilerProviders(settings, input);
  const attempts: string[] = [...resolved.skippedAttempts];
  const attemptedProviders: DecompilerProviderId[] = [];
  const deadline = Date.now() + (runtime.overallTimeoutMs || 12000);

  for (const id of resolved.orderedProviders) {
    const provider = settings.providers[id];
    if (!provider?.enabled) continue;

    if (id === "builtin" && !input.builtinSource) {
      if (input.builtinAvailable) {
        attemptedProviders.push(id);
        const releaseReservation = startProviderAttempt(id);
        releaseReservation();
        return {
          ok: false,
          providerId: "builtin",
          attempts,
          attemptedProviders,
          needsBuiltin: true,
        };
      }

      attempts.push("[builtin] Executor built-in decompile is unavailable or returned no source.");
      continue;
    }

    const remainingMs = deadline - Date.now();
    if (remainingMs <= 0) {
      attempts.push("Overall decompile deadline reached.");
      break;
    }
    attemptedProviders.push(id);

    const providerTimeoutMs = Math.min(
      runtime.providerTimeoutsMs?.[id] ?? DEFAULT_PROVIDER_TIMEOUTS_MS[id] ?? 6000,
      remainingMs
    );
    const displayName = providerDisplayName(id, provider);
    const finishProviderAttempt = startProviderAttempt(id);
    let result: ProviderRunResult;
    try {
      result = await runProvider({
        id,
        provider,
        bytecode,
        bytecodeBase64: input.bytecodeBase64,
        builtinSource: input.builtinSource,
        builtinLatencyMs: input.builtinLatencyMs,
        timeoutMs: providerTimeoutMs,
      });
    } finally {
      finishProviderAttempt();
    }

    if (result.ok && typeof result.result === "string" && result.result !== "") {
      if (isUnusableDecompiledSource(result.result)) {
        recordDecompilerProviderFailure({
          id,
          errorMessage: result.result.trim(),
          runtime,
          statusCode: result.statusCode,
          latencyMs: result.latencyMs,
          clientId: input.clientId,
        });
        attempts.push(`[${id}] ${result.result.trim()}`);
        continue;
      }
      recordDecompilerProviderSuccess(id, result.latencyMs, runtime, input.clientId);
      return {
        ok: true,
        providerId: id,
        source: `-- Decompiled with ${displayName}\n${result.result}`,
        attempts,
        attemptedProviders,
      };
    }

    const error = result.error || "Provider returned no source.";
    recordDecompilerProviderFailure({
      id,
      errorMessage: error,
      runtime,
      statusCode: result.statusCode,
      timedOut: result.timedOut,
      latencyMs: result.latencyMs,
      clientId: input.clientId,
    });
    attempts.push(`[${id}] ${error}`);
  }

  if (attempts.length === 0) {
    attempts.push("No decompiler providers are enabled.");
  }

  return {
    ok: false,
    attempts,
    attemptedProviders,
    error: attempts.join("\n\n"),
  };
}
